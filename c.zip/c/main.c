// Task - 1
/*#include "stdio.h"

void type(int N) {
    for (int i = 2; i < N; i += 2) {
        printf("%d ", i);
    }

    for (int i = (N % 2 == 0 ? N - 1 : N); i >= 1; i -= 2) {
        if (i != N)
            printf("%d ", i);
    }

    printf("\n");
}

int main() {
    int N;

    printf("N sonini kiriting: ");
    scanf("%d", &N);

    type(N);

    return 0;
}*/


// Task - 2
/*#include "stdio.h"

int f(int num) {
    if (num <= 1) return 0;
    if (num == 2) return 1;
    if (num % 2 == 0) return 0;

    for (int i = 3; i * i <= num; i += 2) {
        if (num % i == 0) return 0;
    }
    return 1;
}

void prime(int N) {
    for (int i = 2; i <= N; i++) {
        if (f(i)) {
            printf("%d ", i);
        }
    }
    printf("\n");
}

int main() {
    int N;

    printf("N sonini kiriting: ");
    scanf("%d", &N);

    prime(N);

    return 0;
}*/


// Task - 3
/*#include "stdio.h"

int sum(int N) {
    int sum = 0;
    for (int i = 1; i <= N; i++) {
        sum += i;
    }
    return sum;
}

int main() {
    int N;

    printf("N sonini kiriting: ");
    scanf("%d", &N);

    int result = sum(N);
    printf("1 dan %d gacha bo'lgan sonlarning yig'indisi: %d\n", N, result);

    return 0;
}*/


// Task - 4
/*#include "stdio.h"

char to_lower(char c) {
    if (c >= 'A' && c <= 'Z') {
        return c + ('a' - 'A');
    }
    return c;
}

int main() {
    char i;

    printf("Xohishingizga ko'ra biror narsa kiriting masalan (A) : ");
    scanf(" %c", &i);

    char result = to_lower(i);
    printf("Natija: %c\n", result);

    return 0;
}*/


// Task - 5
/*#include "stdio.h"

int octal(int num) {
    int i = 0, place = 1;

    while (num > 0) {
        int remainder = num % 8;
        i += remainder * place;
        num /= 8;
        place *= 10;
    }

    return i;
}

int main() {
    int number;

    printf("Butun sonni kiriting: ");
    scanf("%d", &number);

    int result = octal(number);
    printf("%d ning sakkizlik sanoq sistemasidagi qiymati: %d\n", number, result);

    return 0;
}*/


// Task - 6
/*#include "stdio.h"

int ekub(int a, int b) {
    while (b != 0) {
        int temp = b;
        b = a % b;
        a = temp;
    }
    return a;
}

int main() {
    int num1, num2;

    printf("Ikki butun sonni kiriting:\n");
    printf("Birinci son: ");
    scanf("%d", &num1);
    printf("Ikkinchi son: ");
    scanf("%d", &num2);

    int result = ekub(num1, num2);
    printf("%d va %d ning eng katta umumiy bo'luvchi: %d\n", num1, num2, result);

    return 0;
}*/


// Task - 7
#include "stdio.h"

const char *days(int N) {
    int today = 0;

    int dw = 7;

    int week = (today + N) % dw;

    switch (week) {
        case 0: return "Dushanba";
        case 1: return "Seshanba";
        case 2: return "Chorshanba";
        case 3: return "Payshanba";
        case 4: return "Juma";
        case 5: return "Shanba";
        case 6: return "Yakshanba";
        default: return "Noma'lum kun";
    }
}

int main() {
    int N;

    printf("N sonini kiriting: ");
    scanf("%d", &N);

    const char *result = days(N);
    printf("Bugun dushanba bo'lsa %d kundan keyin %s bo'ladi.\n", N, result);

    return 0;
}

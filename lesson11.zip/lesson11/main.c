// Task - 4
/*#include "stdio.h"
#include "ctype.h"
#include "string.h"

int main() {
    char input[7];
    int integer = 1, float_ = 0;

    printf("Satrni kiriting: ");
    scanf("%6s", input);

    int length = strlen(input);
    int dot_count = 0;

    for (int i = 0; i < length; i++) {
        if (isdigit(input[i])) {
            continue;
        } else if (input[i] == '.' && dot_count == 0) {
            float_ = 1;
            dot_count++;
        } else {
            integer = 0;
            float_ = 0;
            break;
        }
    }

    if (integer && dot_count == 0) {
        printf("BUTUN\n");
    } else if (float_ && dot_count == 1) {
        printf("KASR\n");
    } else {
        printf("NULL\n");
    }

    return 0;
}*/


// Task - 5
/*#include "stdio.h"
#include "string.h"

void reverse(char text[], char *result) {
    char *start = text;
    char *end = text + strlen(text) - 1;

    while (end >= start) {
        *result = *end;
        result++;
        end--;
    }

    *result = '\0';
}

int main() {
    char text[100];
    char result[100];

    printf("Gapni kiriting: ");
    fgets(text, sizeof(text), stdin);
    text[strcspn(text, "\n")] = '\0';

    reverse(text, result);

    printf("Teskari gap: %s\n", result);

    return 0;
}*/


// Task - 6
/*#include "stdio.h"
int main() {
    FILE *file = fopen("numbers.txt", "r");
    int number;
    int max;

    if (file == NULL) {
        printf("Faylni ochib bo'lmadi.\n");
        return 1;
    }

    if (fscanf(file, "%d", &number) != EOF) {
        max = number;
    } else {
        printf("Fayl bo'sh yoki noto'g'ri.\n");
        fclose(file);
        return 1;
    }

    while (fscanf(file, "%d", &number) != EOF) {
        if (number > max) {
            max = number;
        }
    }

    fclose(file);

    printf("Fayldagi eng katta son: %d\n", max);

    return 0;
}*/


// Task - 7
/*#include "stdio.h"

void bubble(int arr[], int n) {
    int i, j, temp;
    for (i = 0; i < n - 1; i++) {
        for (j = 0; j < n - i - 1; j++) {
            if (arr[j] > arr[j + 1]) {
                temp = arr[j];
                arr[j] = arr[j + 1];
                arr[j + 1] = temp;
            }
        }
    }
}

int main() {
    FILE *file;
    FILE *sort;
    int numbers[10];
    int i;

    file = fopen("numbers.txt", "r");

    if (file == NULL) {
        printf("numbers.txt faylini ochib bo'lmadi.\n");
        return 1;
    }

    for (i = 0; i < 10; i++) {
        fscanf(file, "%d", &numbers[i]);
    }

    fclose(file);

    bubble(numbers, 10);

    sort = fopen("sort_numbers.txt", "w");

    if (sort == NULL) {
        printf("sorted_numbers.txt faylini ochib bo'lmadi.\n");
        return 1;
    }

    for (i = 0; i < 10; i++) {
        fprintf(sort, "%d ", numbers[i]);
    }

    fclose(sort);

    printf("Sonlar o'sish tartibida sorted_numbers.txt fayliga saqlandi.\n");

    return 0;
}*/


// Task - 8
/*#include "stdio.h"

void split(float num, int *integer, float *fractional) {
    *integer = (int)num;
    *fractional = num - *integer;
}

int main() {
    float num1, num2;
    int x, y;
    float a, b;
    float whole, fraction;

    printf("Birinchi sonni kiriting: ");
    scanf("%f", &num1);
    printf("Ikkinchi sonni kiriting: ");
    scanf("%f", &num2);

    split(num1, &x, &a);
    split(num2, &y, &b);

    whole = x + y;
    fraction = a + b;

    if (whole > fraction) {
        printf("Eng katta yig'indi butun qismlarniki: %.2f\n", whole);
    } else {
        printf("Eng katta yig'indi kasr qismlarniki: %.2f\n", fraction);
    }

    return 0;
}*/


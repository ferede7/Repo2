// Task - 1
/*#include "stdio.h"
int main() {
    FILE * file = fopen("numbers.txt", "r");
    int num, count = 0;
    double sum = 0;

    if ( file == NULL) {
        printf("Faylni ochishda xatolik yuz berdi!\n");
        return 1;
    }

    while (fscanf(file, "%d", &num) == 1) {
        sum += num;
        count++;
    }
    fclose(file);

    if (count > 0) {
        printf("Sonlarning o'rta arifmetigi: %.2f\n", sum / count);
    } else {
        printf("Faylda sonlar topilmadi!\n");
    }

    return 0;
}*/


// Task - 2
/*#include "stdio.h"

long double power(float base, int exponent) {
    if (exponent == 0) {
        return 1;
    } else if (exponent > 0) {
        return base * power(base, exponent - 1);
    } else {
        return 1 / power(base, -exponent);
    }
}

int main() {
    float base;
    int exponent;

    printf("Sonni kiriting: ");
    scanf("%f", &base);

    printf("Darajani kiriting: ");
    scanf("%d", &exponent);

    long double result = power(base, exponent);

    printf("%.2f ning %d-darajasi = %.10Lf\n", base, exponent, result);

    return 0;
}*/


// Task - 3
/*#include "stdio.h"

void increasing(int A, int B) {
    if (A > B) return;
    printf("%d ", A);
    increasing(A + 1, B);
}

void decreasing(int A, int B) {
    if (A < B) return;
    printf("%d ", A);
    decreasing(A - 1, B);
}

void range(int A, int B) {
    if (A < B) {
        increasing(A, B);
    } else {
        decreasing(A, B);
    }
}

int main() {
    int A, B;

    printf("A ni kiriting: ");
    scanf("%d", &A);
    printf("B ni kiriting: ");
    scanf("%d", &B);

    range(A, B);

    return 0;
}*/


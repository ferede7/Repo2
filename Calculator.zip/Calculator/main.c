// Calculator
#include "stdio.h"
#include "ctype.h"
#include "string.h"
#include "math.h"

double calc(double x, double y, char op) {
    switch (op) {
        case '+': return x + y;
        case '-': return x - y;
        case '*': return x * y;
        case '/': return x / y;
        case '^': return pow(x, y);
        case '%': return fmod(x, y);
        default: return 0;
    }
}

double eval_expr(char* expr) {
    double vals[100];
    char ops[100];
    int vi = -1, oi = -1;

    for (int i = 0; i < strlen(expr); i++) {
        if (isdigit(expr[i])) {
            double num = 0;
            while (i < strlen(expr) && isdigit(expr[i])) {
                num = num * 10 + (expr[i] - '0');
                i++;
            }
            if (i < strlen(expr) && expr[i] == '.') {
                double dec_part = 0.0;
                double dec_place = 10.0;
                i++;
                while (i < strlen(expr) && isdigit(expr[i])) {
                    dec_part += (expr[i] - '0') / dec_place;
                    dec_place *= 10;
                    i++;
                }
                num += dec_part;
            }
            vals[++vi] = num;
            i--;
        } else if (expr[i] == '(') {
            ops[++oi] = expr[i];
        } else if (expr[i] == ')') {
            while (oi != -1 && ops[oi] != '(') {
                double y = vals[vi--];
                double x = vals[vi--];
                char op = ops[oi--];
                vals[++vi] = calc(x, y, op);
            }
            oi--;
        } else if (strchr("+-*/^%", expr[i])) {
            while (oi != -1 && strchr("+-*/^%", ops[oi])
                && strchr("+-*/^%", ops[oi]) >= strchr("+-*/^%", expr[i])) {
                double y = vals[vi--];
                double x = vals[vi--];
                char op = ops[oi--];
                vals[++vi] = calc(x, y, op);
            }
            ops[++oi] = expr[i];
        }
    }

    while (oi != -1) {
        double y = vals[vi--];
        double x = vals[vi--];
        char op = ops[oi--];
        vals[++vi] = calc(x, y, op);
    }

    return vals[vi];
}

void run_calc() {
    char expr[100];

    while (1) {
        printf("Enter the operation: ");
        scanf("%s", expr);

        double res = eval_expr(expr);
        printf("Result: %lf\n", res);
    }
}

int main() {
    run_calc();
    printf("Calculator has been exited.\n");
    return 0;
}
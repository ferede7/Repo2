// Task - 1
/*#include "stdio.h"

int main() {
    int numbers[10] = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
    int i;

    for (i = 9; i >= 0; i--) {
        printf("%d ", numbers[i]);
    }

    printf("\n");

    return 0;
}*/


// Task - 2
/*#include "stdio.h"

int main() {
    int numbers[10] = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
    int sum = 0;
    int i;

    for (i = 0; i < 10; i++) {
        sum += numbers[i];
    }

    printf("Arrayning qiymatlari yig'indisi: %d\n", sum);

    return 0;
}*/


// Task - 3
/*#include "stdio.h"

int main() {
    int numbers[10] = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
    int i;

    for (i = 9; i >= 0; i--) {
        if (numbers[i] % 2 == 0) {
            printf("%d ", numbers[i]);
        }
    }

    printf("\n");

    return 0;
}*/


// Task - 4
/*#include "stdio.h"

int main() {
    int A[10] = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
    int i;
    int sum = 0;
    int product = 1;
    int odd = 0;

    for (i = 0; i < 10; i++) {
        if (A[i] % 2 == 0) {
            sum += A[i];
        } else {
            product *= A[i];
            odd = 1;
        }
    }

    printf("Juft sonlarning yig'indisi = %d\n", sum);
    if (odd) {
        printf("Toq sonlarning ko'paytmasi = %d\n", product);
    } else {
        printf("Toqlar - 0 (Toq sonlar mavjud emas)\n");
    }

    return 0;
}*/


// Task - 5
/*#include "stdio.h"

int main() {
    int A[10] = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
    int temp;

    temp = A[0];
    A[0] = A[9];
    A[9] = temp;

    for (int i = 0; i < 10; i++) {
        printf("%d ", A[i]);
    }
    printf("\n");

    return 0;
}*/


// Task - 6
/*#include "stdio.h"

int main() {
    int A[10] = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
    int product = 1;
    int sum = 0;

    for (int i = 0; i < 10; i += 2) {
        product *= A[i];
    }

    for (int i = 0; i < 10; i += 2) {
        sum += A[i];
    }

    printf("Product = %d  Sum = %d\n", product, sum);

    return 0;
}*/


// Task - 7
/*#include "stdio.h"

int main() {
    int A[10];
    int min1, min2;
    int i;

    printf("10 ta butun son kiriting:\n");
    for (i = 0; i < 10; i++) {
        scanf("%d", &A[i]);
    }

    if (A[0] < A[1]) {
        min1 = A[0];
        min2 = A[1];
    } else {
        min1 = A[1];
        min2 = A[0];
    }

    for (i = 2; i < 10; i++) {
        if (A[i] < min1) {
            min2 = min1;
            min1 = A[i];
        } else if (A[i] < min2 && A[i] != min1) {
            min2 = A[i];
        }
    }

    if (min2 == min1) {
        printf("Ikkinchi eng kichik qiymat mavjud emas.\n");
    } else {
        printf("Ikkinchi eng kichik qiymat: %d\n", min2);
    }

    return 0;
}*/


// Task - 8
/*#include "stdio.h"

int main() {
    int A[10];
    int max1, max2;
    int i;

    printf("10 ta butun son kiriting:\n");
    for (i = 0; i < 10; i++) {
        scanf("%d", &A[i]);
    }

    if (A[0] > A[1]) {
        max1 = A[0];
        max2 = A[1];
    } else {
        max1 = A[1];
        max2 = A[0];
    }

    for (i = 2; i < 10; i++) {
        if (A[i] > max1) {
            max2 = max1;
            max1 = A[i];
        } else if (A[i] > max2 && A[i] != max1) {
            max2 = A[i];
        }
    }

    if (max1 == max2) {
        printf("Ikkinchi eng katta qiymat mavjud emas.\n");
    } else {
        printf("Ikkinchi eng katta qiymat: %d\n", max2);
    }

    return 0;
}*/


// Task - 9
/*#include "stdio.h"

int main() {
    int n;
    printf("Massivdagi elementlar sonini kiriting: ");
    scanf("%d", &n);

    int A[n];
    int i;

    printf("Massiv elementlarini kiriting:\n");
    for (i = 0; i < n; i++) {
        scanf("%d", &A[i]);
    }

    int max = A[0];
    for (i = 1; i < n; i++) {
        if (A[i] > max) {
            max = A[i];
        }
    }

    int count = 0;
    int found = 0;
    for (i = 0; i < n; i++) {
        if (A[i] == max) {
            found = 1;
        } else if (found) {
            count++;
        }
    }

    printf("Max (o'zini hisobga olmasdan) keyin %d son bor.\n", count);

    return 0;
}
*/


// Task - 10
/*#include "stdio.h"

int main() {
    int n;
    printf("Massivdagi elementlar sonini kiriting: ");
    scanf("%d", &n);

    int A[n];
    int i;

    printf("Massiv elementlarini kiriting:\n");
    for (i = 0; i < n; i++) {
        scanf("%d", &A[i]);
    }

    int min = A[0];
    for (i = 1; i < n; i++) {
        if (A[i] < min) {
            min = A[i];
        }
    }

    int count = 0;
    for (i = 0; i < n; i++) {
        if (A[i] == min) {
            break;
        }
        count++;
    }

    printf("Mindan oldin %d ta son bor\n", count);

    return 0;
}*/


// Task - 11
/*#include "stdio.h"

void find(int arr[], int n) {
    int max = arr[0];
    int min = arr[0];
    int index1 = 0, index2 = 0;

    for (int i = 1; i < n; i++) {
        if (arr[i] > max) {
            max = arr[i];
            index1 = i;
        }
        if (arr[i] < min) {
            min = arr[i];
            index2 = i;
        }
    }

    int count = 0;
    if (index1 > index2) {
        for (int i = index2 + 1; i < index1; i++) {
            count++;
        }
    } else {
        for (int i = index1 + 1; i < index2; i++) {
            count++;
        }
    }

    printf("Max va min orasida %d ta son bor\n", count);
}

int main() {
    int n;

    printf("Nechta son kiritmoqchisiz? ");
    scanf("%d", &n);

    int arr[n];

    printf("Sonlarni kiriting:\n");
    for (int i = 0; i < n; i++) {
        scanf("%d", &arr[i]);
    }

    find(arr, n);

    return 0;
}*/



// Task - 12
/*#include "stdio.h"

int main() {
    int n;
    printf("Massivdagi elementlar sonini kiriting: ");
    scanf("%d", &n);

    if (n <= 1) {
        printf("Massivda yetarlicha element mavjud emas.\n");
        return 0;
    }

    int A[n];
    int i;

    printf("Massiv elementlarini kiriting:\n");
    for (i = 0; i < n; i++) {
        scanf("%d", &A[i]);
    }

    int max = A[0];
    int min = A[0];
    int index1 = 0;
    int index2 = 0;

    for (i = 1; i < n; i++) {
        if (A[i] > max) {
            max = A[i];
            index1 = i;
        }
        if (A[i] < min) {
            min = A[i];
            index2 = i;
        }
    }

    int temp = A[index1];
    A[index1] = A[index2];
    A[index2] = temp;

    printf("Almashtirilgan massiv:\n");
    for (i = 0; i < n; i++) {
        printf("%d ", A[i]);
    }
    printf("\n");

    return 0;
}*/


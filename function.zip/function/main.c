// Task - 1
/*#include "stdio.h"

void even(int N) {
    int sum = 0;

    for (int i = 1; i <= N; i++) {
        if (i % 2 == 0) {
            sum += i;
        }
    }

    printf("The sum of all even numbers from 1 to %d is: %d\n", N, sum);
}

int main() {
    int N;

    printf("Enter the number for value N: ");
    scanf("%d", &N);

    if (N <= 0) {
        printf("N should be a positive number.\n");
        return 1;
    }

    even(N);

    return 0;
}*/


// Task - 2
/*#include "stdio.h"

void rectangle(int A, int B) {
    for (int i = 0; i < A; i++) {
        for (int j = 0; j < B; j++) {
            if (i == 0 || i == A - 1 || j == 0 || j == B - 1) {
                printf("* ");
            } else {
                printf("  ");
            }
        }
        printf("\n");
    }
}

int main() {
    int A, B;

    printf("Enter the number of rows (A): ");
    scanf("%d", &A);
    printf("Enter the number of columns (B): ");
    scanf("%d", &B);

    if (A <= 0 || B <= 0) {
        printf("A and B should be positive integers.\n");
        return 1;
    }

    if (A < 2 || B < 2) {
        printf("A and B should be at least 2 to form a hollow rectangle.\n");
        return 1;
    }

    rectangle(A, B);

    return 0;
}*/


// Task - 3
/*#include "stdio.h"

void average(int N) {
    if (N <= 0) {
        printf("The number of elements must be positive.\n");
        return;
    }

    float sum = 0.0;
    float number;

    printf("Enter %d float numbers:\n", N);
    for (int i = 0; i < N; i++) {
        scanf("%f", &number);
        sum += number;
    }

    float average = sum / N;
    printf("The average of the entered numbers is: %.2f\n", average);
}

int main() {
    int N;

    printf("Enter the number of float numbers to be averaged (N): ");
    scanf("%d", &N);

    average(N);

    return 0;
}*/


// Task - 4
/*#include <stdio.h>
#include <stdbool.h>

bool isPrime(int num) {
    if (num <= 1) return false;
    if (num == 2) return true;
    if (num % 2 == 0) return false;

    for (int i = 3; i * i <= num; i += 2) {
        if (num % i == 0) return false;
    }

    return true;
}

void checkPrime(int num) {
    if (isPrime(num)) {
        printf("%d is a prime number.\n", num);
    } else {
        printf("%d is not a prime number.\n", num);
    }
}

int main() {
    int number;

    printf("Enter a number: ");
    scanf("%d", &number);

    checkPrime(number);

    return 0;
}*/


// Task - 6
/*#include "stdio.h"

void age(int birth, int i) {
    int age = i - birth;

    printf("%d-yilda tug‘ilganlar %d yosh.\n", birth, age);
}

int main() {
    int birth;
    int i = 2024;

    printf("Tug‘ilgan yilni kiriting: ");
    scanf("%d", &birth);

    age(birth, i);

    return 0;
}*/


// Exercise - 1
/*#include "stdio.h"

int power(int A, int B) {
    int result = 1;

    for (int i = 0; i < B; i++) {
        result *= A;
    }

    return result;
}

int main() {
    int A, B;

    printf("Bir sonni kiriting: ");
    scanf("%d", &A);
    printf("Endi uning darajasini kiriting ( nechi bo'lsin?): ");
    scanf("%d", &B);

    int result = power(A, B);

    printf("%d ning %d-darajasi: %d\n", A, B, result);

    return 0;
}*/


// Exercise - 2
/*#include "stdio.h"

void decimal(int n) {
    if (n > 0) {
        decimal(n / 2);
        printf("%d", n % 2);
    }
}

int main() {
    int number;

    printf("Butun sonni kiriting: ");
    scanf("%d", &number);

    if (number == 0)
        printf("0");
    else {
        printf("Ikkilik sanoq sistemasidagi qiymat: ");
        decimal(number);
    }

    return 0;
}*/

// 1
/*#include "stdio.h"

int main() {
    int numbers[10];
    int n = 10;

    printf("10 ta butun son kiriting:\n");
    for (int i = 0; i < n; i++) {
        printf("Son %d: ", i + 1);
        scanf("%d", &numbers[i]);
    }

    for (int i = 0; i < n - 1; i++) {
        for (int j = 0; j < n - i - 1; j++) {
            if (numbers[j] > numbers[j + 1]) {
                int temp = numbers[j];
                numbers[j] = numbers[j + 1];
                numbers[j + 1] = temp;
            }
        }
    }

    printf("O'sish tartibida sonlar:\n");
    for (int i = 0; i < n; i++) {
        printf("%d ", numbers[i]);
    }
    printf("\n");

    return 0;
}*/


// 2
/*#include "stdio.h"

void selection(int arr[], int n) {
    for (int i = 0; i < n - 1; i++) {
        int min = i;
        for (int j = i + 1; j < n; j++) {
            if (arr[j] < arr[min]) {
                min = j;
            }
        }
        int temp = arr[min];
        arr[min] = arr[i];
        arr[i] = temp;
    }
}

int main() {
    int numbers[10];
    int n = 10;

    printf("10 ta butun son kiriting:\n");
    for (int i = 0; i < n; i++) {
        printf("Son %d: ", i + 1);
        scanf("%d", &numbers[i]);
    }

    selection(numbers, n);

    printf("O'sish tartibida sonlar:\n");
    for (int i = 0; i < n; i++) {
        printf("%d ", numbers[i]);
    }
    printf("\n");

    return 0;
}*/



// 3
/*#include "stdio.h"

void in_sertion(int arr[], int n) {
    for (int i = 1; i < n; i++) {
        int point = arr[i];
        int j = i - 1;

        while (j >= 0 && arr[j] > point) {
            arr[j + 1] = arr[j];
            j = j - 1;
        }
        arr[j + 1] = point;
    }
}

int main() {
    int numbers[10];
    int n = 10;

    printf("10 ta butun son kiriting:\n");
    for (int i = 0; i < n; i++) {
        printf("Son %d: ", i + 1);
        scanf("%d", &numbers[i]);
    }

    in_sertion(numbers, n);

    printf("O'sish tartibida sonlar:\n");
    for (int i = 0; i < n; i++) {
        printf("%d ", numbers[i]);
    }
    printf("\n");

    return 0;
}*/

